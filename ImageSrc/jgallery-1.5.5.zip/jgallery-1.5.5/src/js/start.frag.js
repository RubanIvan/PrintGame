( function() {
    "use strict";